# Satuan Intelijen Kodam XXIII / Palaka Wira
## Panduan Deploy Lengkap

---

## Struktur File

```
satuan-intelijen/
├── netlify.toml                    ← Konfigurasi Netlify
├── package.json                    ← Dependencies (nodemailer)
├── public/
│   ├── index.html                  ← Halaman utama
│   └── pages/
│       ├── login.html              ← Portal login internal
│       ├── admin.html              ← Dashboard admin
│       └── publikasi.html          ← Halaman publikasi publik
└── netlify/functions/
    ├── contact.js                  ← API kirim email
    ├── auth.js                     ← API login JWT
    └── publikasi.js                ← API CRUD publikasi
```

---

## Cara Deploy ke Netlify (Free)

### Langkah 1 — Upload ke GitHub
1. Buat akun di https://github.com
2. Buat repository baru: `satuan-intelijen`
3. Upload seluruh folder ini ke repository
   - Bisa via GitHub Desktop atau drag-drop di browser

### Langkah 2 — Deploy di Netlify
1. Buka https://netlify.com → Login/Daftar
2. Klik **"Add new site" → "Import an existing project"**
3. Pilih **GitHub** → authorize → pilih repository `satuan-intelijen`
4. Build settings:
   - **Publish directory:** `public`
   - **Build command:** (kosongkan)
5. Klik **Deploy site**

### Langkah 3 — Set Environment Variables ⚠️ WAJIB
Di Netlify Dashboard → Site → **Site configuration → Environment variables → Add variable**

| Variable | Nilai | Keterangan |
|---|---|---|
| `GMAIL_USER` | email@gmail.com | Email Gmail pengirim |
| `GMAIL_PASS` | xxxx xxxx xxxx xxxx | App Password Gmail* |
| `NOTIFY_EMAIL` | notif@email.com | Email tujuan notifikasi |
| `ADMIN_USERNAME` | admin | Username login portal |
| `ADMIN_PASSWORD` | GantiPasswordIni! | Password login portal |
| `JWT_SECRET` | string-panjang-acak-min-32-char | Kunci enkripsi JWT |

> **Cara buat Gmail App Password:**
> 1. Aktifkan 2-Factor Authentication di Gmail
> 2. Buka https://myaccount.google.com/apppasswords
> 3. Pilih "Mail" → "Other (Custom)" → beri nama → Generate
> 4. Salin 16 karakter yang muncul → masukkan ke `GMAIL_PASS`

### Langkah 4 — Deploy ulang
Setelah set environment variables, klik **Deploys → Trigger deploy → Deploy site**

---

## URL Halaman

| Halaman | URL |
|---|---|
| Beranda | `https://nama-site.netlify.app/` |
| Publikasi | `https://nama-site.netlify.app/publikasi` |
| Login Portal | `https://nama-site.netlify.app/pages/login.html` |
| Admin Dashboard | `https://nama-site.netlify.app/admin` |

---

## Custom Domain (Opsional)

Di Netlify → **Domain management → Add domain**
- Untuk domain `.mil.id` hubungi PUSINFOLAHTA TNI

---

## Fitur yang Tersedia

✅ Landing page profesional  
✅ Form kontak → kirim email otomatis + auto-reply  
✅ Portal login internal (JWT, proteksi brute-force)  
✅ Admin dashboard (manajemen publikasi)  
✅ Halaman publikasi publik dengan filter & search  
✅ REST API (contact, auth, publikasi)  
✅ Dark/light mode  
✅ Responsive mobile  
✅ SEO ready  

---

## Catatan Keamanan

- Ganti `ADMIN_PASSWORD` dan `JWT_SECRET` sebelum deploy produksi
- JWT token expired dalam 24 jam
- Login portal memiliki proteksi max 5 percobaan gagal
- Semua endpoint API dilindungi CORS

---

© 2026 Satuan Intelijen Kodam XXIII / Palaka Wira
